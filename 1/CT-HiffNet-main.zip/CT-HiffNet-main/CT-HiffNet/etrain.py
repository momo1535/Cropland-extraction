from torch.autograd import Variable
import os
import argparse
from datetime import datetime
from utils.tdataloader import get_loader
from utils.utils import clip_gradient, AvgMeter, poly_lr
from net.CTHiffNet import *


file = open("log/BGNet.txt", "a")
def structure_loss(pred, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(pred, mask, reduction='mean')
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))
    pred = torch.sigmoid(pred)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    C = torch.zeros_like(weit)
    C[pred + mask > 0] = 1
    C_area = C.sum(dim=(2, 3))
    closure_diff = C_area - union
    wgiou = 1 - (inter + 1) / (union - inter + 1) - closure_diff / C_area

    return (wbce + wgiou).mean()


def dice_loss(predict, target):
    smooth = 1
    p = 2
    valid_mask = torch.ones_like(target)
    predict = predict.contiguous().view(predict.shape[0], -1)
    target = target.contiguous().view(target.shape[0], -1)
    valid_mask = valid_mask.contiguous().view(valid_mask.shape[0], -1)
    num = torch.sum(torch.mul(predict, target) * valid_mask, dim=1) * 2 + smooth
    den = torch.sum((predict.pow(p) + target.pow(p)) * valid_mask, dim=1) + smooth
    loss = 1 - num / den
    return loss.mean()


def train(train_loader, model, optimizer, epoch):
    model.train()

    loss_record3, loss_record2, loss_record1, loss_recorde = AvgMeter(), AvgMeter(), AvgMeter(), AvgMeter()
    for i, pack in enumerate(train_loader, start=1):
        optimizer.zero_grad()
        images, gts = pack
        images = Variable(images).cuda()
        gts = Variable(gts).cuda()
        lateral_map_3, lateral_map_2, lateral_map_1, edge_map = model(images)
        loss3 = structure_loss(lateral_map_3, gts)
        loss2 = structure_loss(lateral_map_2, gts)
        loss1 = structure_loss(lateral_map_1, gts)
        losse = dice_loss(edge_map, edge_map)
        loss = loss3 + loss2 + loss1 + 3*losse
        loss.backward()
        clip_gradient(optimizer, opt.clip)
        optimizer.step()
        loss_record3.update(loss3.data, opt.batchsize)
        loss_record2.update(loss2.data, opt.batchsize)
        loss_record1.update(loss1.data, opt.batchsize)
        loss_recorde.update(losse.data, opt.batchsize)
        if i % 60 == 0 or i == total_step:
            print('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
                  '[lateral-3: {:.4f}], [lateral-2: {:.4f}], [lateral-1: {:.4f}], [edge: {:,.4f}]'.
                  format(datetime.now(), epoch, opt.epoch, i, total_step,
                         loss_record3.avg, loss_record2.avg, loss_record1.avg, loss_recorde.avg))
            file.write('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
                       '[lateral-3: {:.4f}], [lateral-2: {:.4f}], [lateral-1: {:.4f}], [edge: {:,.4f}]\n'.
                       format(datetime.now(), epoch, opt.epoch, i, total_step,
                         loss_record3.avg, loss_record2.avg, loss_record1.avg, loss_recorde.avg))

    save_path = 'checkpoints/{}/'.format(opt.train_save)
    os.makedirs(save_path, exist_ok=True)
    if (epoch + 1) % 5 == 0 or (epoch + 1) == opt.epoch:
        torch.save(model.state_dict(), save_path + 'BGNet-%d.pth' % epoch)
        print('[Saving Snapshot:]', save_path + 'BGNet-%d.pth' % epoch)
        file.write('[Saving Snapshot:]' + save_path + 'BGNet-%d.pth' % epoch + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int,
                        default=300, help='epoch number')
    parser.add_argument('--lr', type=float,
                        default=1e-4, help='learning rate')
    parser.add_argument('--batchsize', type=int,
                        default=8, help='training batch size')
    parser.add_argument('--trainsize', type=int,
                        default=256, help='training dataset size')
    parser.add_argument('--clip', type=float,
                        default=0.5, help='gradient clipping margin')
    parser.add_argument('--train_path', type=str,
                        default=r'F:\Code\CT-HiffNet\data', help='path to train dataset')
    parser.add_argument('--path', type=str, default=None, help='path to pre-trained model')
    parser.add_argument('--train_save', type=str,
                        default='name')
    opt = parser.parse_args()
    model = GeneralNet(BBk,[3, 4, 6, 3]).cuda()
    params = model.parameters()
    optimizer = torch.optim.Adam(params, opt.lr)
    image_root = '{}/Imgs/'.format(opt.train_path)
    gt_root = '{}/GT/'.format(opt.train_path)
    edge_root = '{}/Edge/'.format(opt.train_path)
    train_loader = get_loader(image_root, gt_root, batchsize=opt.batchsize, trainsize=opt.trainsize)
    total_step = len(train_loader)
    if opt.path is not None:
        print(f'Loading model from {opt.path}')
        checkpoint = torch.load(opt.path)
        start_epoch = checkpoint['epoch'] + 1
        model.load_state_dict(checkpoint['model_state_dict'])
    else:
        save_path = 'checkpoints/{}/'.format(opt.train_save)
        if os.path.exists(save_path):
            model_file_list = sorted(os.listdir(save_path), key=lambda x: int(x.split('-')[-1].split('.')[0]))
            if len(model_file_list) > 0:
                latest_model_file = model_file_list[-1]
                latest_model_path = os.path.join(save_path, latest_model_file)
                print(f'Loading model from {latest_model_path}')
                checkpoint = torch.load(latest_model_path)
                start_epoch = checkpoint['epoch'] + 1
                model.load_state_dict(checkpoint['model_state_dict'])
            else:
                start_epoch = 0
                print('No pre-trained model found. Starting training from scratch.')
        else:
            start_epoch = 0
            print('No pre-trained model found. Starting training from scratch.')

    print("Start Training")

    for epoch in range(start_epoch, opt.epoch):
        poly_lr(optimizer, opt.lr, epoch, opt.epoch)
        train(train_loader, model, optimizer, epoch)

        save_path = 'checkpoints/{}/'.format(opt.train_save)
        os.makedirs(save_path, exist_ok=True)
        if (epoch + 1) % 5 == 0 or (epoch + 1) == opt.epoch:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict()
            }, save_path + 'BGNet-%d.pth' % epoch)
            print('[Saving Snapshot:]', save_path + 'BGNet-%d.pth' % epoch)
            file.write('[Saving Snapshot:]' + save_path + 'BGNet-%d.pth' % epoch + '\n')

    file.close()
