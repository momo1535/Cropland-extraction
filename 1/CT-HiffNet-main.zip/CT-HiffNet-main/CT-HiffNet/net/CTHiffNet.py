import torch
import torch.nn as nn
import torch.nn.functional as F
from math import log


class ConvBNR(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=3, stride=1, dilation=1, bias=False):
        super(ConvBNR, self).__init__()

        self.block = nn.Sequential(
            nn.Conv2d(inplanes, planes, kernel_size, stride=stride, padding=dilation, dilation=dilation, bias=bias),
            nn.BatchNorm2d(planes),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return self.relu(x)


class FeatureAdaptor(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(FeatureAdaptor, self).__init__()
        self.relu = nn.ReLU(True)
        self.branch1 = nn.Sequential(
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 3), padding=(0, 1)),
            BasicConv2d(out_channel, out_channel, kernel_size=(3, 1), padding=(1, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=3, dilation=3)
        )
        self.branch2 = nn.Sequential(
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 5), padding=(0, 2)),
            BasicConv2d(out_channel, out_channel, kernel_size=(5, 1), padding=(2, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=5, dilation=5)
        )
        self.branch3 = nn.Sequential(
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 7), padding=(0, 3)),
            BasicConv2d(out_channel, out_channel, kernel_size=(7, 1), padding=(3, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=7, dilation=7)
        )
        self.conv_cat = BasicConv2d(3*out_channel, out_channel, 3, padding=1)
        self.conv_res = BasicConv2d(out_channel, out_channel, 1)

    def forward(self, x):
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)
        x_cat = self.conv_cat(torch.cat((x1, x2, x3), 1))
        x = self.conv_res(x)
        x = self.relu(x_cat + x)

        return x



class ChannelReducer(nn.Module):
    def __init__(self, inplanes, planes):
        super(ChannelReducer, self).__init__()
        self.conv = nn.Conv2d(inplanes, planes, 1)
        self.bn = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)

        return x


class Conv_Block(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(Conv_Block, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(in_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False),
            nn.BatchNorm2d(out_channel),
            nn.Dropout2d(0.3),
            nn.LeakyReLU(),
            nn.Conv2d(out_channel, out_channel, 3, 1, 1, padding_mode='reflect', bias=False),
            nn.BatchNorm2d(out_channel),
            nn.Dropout2d(0.3),
            nn.LeakyReLU()
        )

    def forward(self, x):
        return self.layer(x)

class AuxModule(nn.Module):
    def __init__(self):
        super(AuxModule, self).__init__()
        self.reduce1 = ChannelReducer(128, 64)
        self.reduce2 = ChannelReducer(256, 128)
        self.reduce3 = ChannelReducer(512, 256)
        self.block = nn.Sequential(
            ConvBNR(256 + 128 + 64, 256, 3),
            ConvBNR(256, 256, 3),
            nn.Conv2d(256, 1, 1))


    def forward(self, x3,x2, x1):
        size = x1.size()[2:]
        x1 = self.reduce1(x1)
        x2 = self.reduce2(x2)
        x2 = F.interpolate(x2, size, mode='bilinear', align_corners=False)
        x3 = self.reduce3(x3)
        x3 = F.interpolate(x3, size, mode='bilinear', align_corners=False)
        out = torch.cat((x3, x2, x1), dim=1)
        out = self.block(out)

        return out



class FeatureEnhancer(nn.Module):
    def __init__(self, channel):
        super(FeatureEnhancer, self).__init__()
        t = int(abs((log(channel, 2) + 1) / 2))
        k = t if t % 2 else t + 1
        self.conv2d = ConvBNR(channel, channel, 3)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv1d = nn.Conv1d(1, 1, kernel_size=k, padding=(k - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, c, att):
        if c.size() != att.size():
            att = F.interpolate(att, c.size()[2:], mode='bilinear', align_corners=False)
        x = c * att + c
        x = self.conv2d(x)
        wei = self.avg_pool(x)
        wei = self.conv1d(wei.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        wei = self.sigmoid(wei)
        x = x * wei

        return x


class FusionUnit(nn.Module):
    def __init__(self, hchannel, channel):
        super(FusionUnit, self).__init__()
        self.conv1_1 = ChannelReducer(hchannel + channel, channel)
        self.conv3_1 = ConvBNR(channel // 4, channel // 4, 3)
        self.dconv5_1 = ConvBNR(channel // 4, channel // 4, 3, dilation=2)
        self.dconv7_1 = ConvBNR(channel // 4, channel // 4, 3, dilation=3)
        self.dconv9_1 = ConvBNR(channel // 4, channel // 4, 3, dilation=4)
        self.conv1_2 = ChannelReducer(channel, channel)
        self.conv3_3 = ConvBNR(channel, channel, 3)

    def forward(self, lf, hf):
        if lf.size()[2:] != hf.size()[2:]:
            hf = F.interpolate(hf, size=lf.size()[2:], mode='bilinear', align_corners=False)
        x = torch.cat((lf, hf), dim=1)
        x = self.conv1_1(x)
        xc = torch.chunk(x, 4, dim=1)
        x0 = self.conv3_1(xc[0] + xc[1] + xc[2] + xc[3])
        x1 = self.dconv5_1(xc[1] + x0 + xc[2] + xc[3])
        x2 = self.dconv7_1(xc[2] + x0 + x1 + xc[3])
        x3 = self.dconv9_1(xc[3] + x0 + x1 + x2)
        xx = self.conv1_2(torch.cat((x0, x1, x2, x3), dim=1))
        x = self.conv3_3(x + xx)

        return x


class BBk(nn.Module):
    expansion = 1

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.shrinkage = Shrinkage(out_channels, gap_size=(1, 1))
        self.residual_function = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels * BBk.expansion, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels * BBk.expansion),
            self.shrinkage
        )
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != BBk.expansion * out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels * BBk.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels * BBk.expansion)
            )

    def forward(self, x):
        return nn.ReLU(inplace=True)(self.residual_function(x) + self.shortcut(x))


class Shrinkage(nn.Module):
    def __init__(self, channel, gap_size):
        super(Shrinkage, self).__init__()
        self.gap = nn.AdaptiveAvgPool2d(gap_size)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel),
            nn.BatchNorm1d(channel),
            nn.ReLU(inplace=True),
            nn.Linear(channel, channel),
            nn.Sigmoid(),
        )

    def forward(self, x):
        x_raw = x
        x = torch.abs(x)
        x_abs = x
        x = self.gap(x)
        x = torch.flatten(x, 1)
        average = x
        x = self.fc(x)
        x = torch.mul(average, x)
        x = x.unsqueeze(2).unsqueeze(2)
        sub = x_abs - x
        zeros = sub - sub
        n_sub = torch.max(sub, zeros)
        x = torch.mul(torch.sign(x_raw), n_sub)
        return x


class GeneralNet(nn.Module):
    def __init__(self, block, layers):
        super(GeneralNet, self).__init__()

        base_ch = 64
        self.stem = nn.Sequential(
            nn.Conv2d(3, base_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True)
        )

        # backbone
        self.stage1 = self._make_stage(block, 128, layers[0], 2)
        self.stage2 = self._make_stage(block, 256, layers[1], 2)
        self.stage3 = self._make_stage(block, 512, layers[2], 2)
        self.stage4 = self._make_stage(block, 1024, layers[3], 2)
        self.adapt1 = FeatureAdaptor(128, 128)
        self.adapt2 = FeatureAdaptor(256, 256)
        self.adapt3 = FeatureAdaptor(512, 512)
        self.aux_module = AuxModule()
        self.enh1 = FeatureEnhancer(128)
        self.enh2 = FeatureEnhancer(256)
        self.enh3 = FeatureEnhancer(512)
        self.enh4 = FeatureEnhancer(1024)
        self.reduce1 = ChannelReducer(128, 64)
        self.reduce2 = ChannelReducer(256, 128)
        self.reduce3 = ChannelReducer(512, 256)
        self.reduce4 = ChannelReducer(1024, 256)
        self.fuse1 = FusionUnit(128, 64)
        self.fuse2 = FusionUnit(256, 128)
        self.fuse3 = FusionUnit(256, 256)
        self.out1 = nn.Conv2d(64, 1, 1)
        self.out2 = nn.Conv2d(128, 1, 1)
        self.out3 = nn.Conv2d(256, 1, 1)
        self.in_channels = base_ch

    def _make_stage(self, block, out_ch, n_blocks, stride):
        s = [stride] + [1] * (n_blocks - 1)
        layers = []
        for st in s:
            layers.append(block(self.in_channels, out_ch, st))
            self.in_channels = out_ch * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        x0 = self.stem(x)
        x1 = self.stage1(x0)
        x2 = self.stage2(x1)
        x3 = self.stage3(x2)
        x4 = self.stage4(x3)
        r1 = self.adapt1(x1)
        r2 = self.adapt2(x2)
        r3 = self.adapt3(x3)
        aux = self.aux_module(r3, r2, r1)
        aux_mask = torch.sigmoid(aux)
        f1 = self.enh1(x1, aux_mask)
        f2 = self.enh2(x2, aux_mask)
        f3 = self.enh3(x3, aux_mask)
        f4 = self.enh4(x4, aux_mask)
        r1 = self.reduce1(f1)
        r2 = self.reduce2(f2)
        r3 = self.reduce3(f3)
        r4 = self.reduce4(f4)
        m3 = self.fuse3(r3, r4)
        m2 = self.fuse2(r2, m3)
        m1 = self.fuse1(r1, m2)
        o3 = F.interpolate(self.out3(m3), scale_factor=8, mode='bilinear', align_corners=False)
        o2 = F.interpolate(self.out2(m2), scale_factor=4, mode='bilinear', align_corners=False)
        o1 = F.interpolate(self.out1(m1), scale_factor=2, mode='bilinear', align_corners=False)
        oe = F.interpolate(aux_mask, scale_factor=2, mode='bilinear', align_corners=False)
        return o3, o2, o1, oe


if __name__ == '__main__':
    batch_size = 4
    img_height = 256
    img_width = 256

    device = "cuda" if torch.cuda.is_available() else "cpu"
    input = torch.rand(batch_size, 3, img_height, img_width).to(device)
    print(f"input shape: {input.shape}")
    model = GeneralNet(BBk,[3, 4, 6, 3]).to(device)
    output = model(input)
    print(f"output shapes: {[t.shape for t in output]}")